function ambilMatriks() {
  const A = [
    [parseFloat(document.getElementById("a11").value) || 0,
     parseFloat(document.getElementById("a12").value) || 0],
    [parseFloat(document.getElementById("a21").value) || 0,
     parseFloat(document.getElementById("a22").value) || 0]
  ];
  const B = [
    [parseFloat(document.getElementById("b11").value) || 0,
     parseFloat(document.getElementById("b12").value) || 0],
    [parseFloat(document.getElementById("b21").value) || 0,
     parseFloat(document.getElementById("b22").value) || 0]
  ];
  return { A, B };
}

function tambahMatriks() {
  const { A, B } = ambilMatriks();

  let langkah = "🧮 Langkah-langkah Penjumlahan Matriks A + B:\n\n";
  let hasil = [[], []];

  for (let i = 0; i < 2; i++) {
    for (let j = 0; j < 2; j++) {
      const penjumlahan = `${A[i][j]} + ${B[i][j]} = ${A[i][j] + B[i][j]}`;
      hasil[i][j] = A[i][j] + B[i][j];
      langkah += `Elemen [${i+1},${j+1}]: ${penjumlahan}\n`;
    }
  }

  langkah += `\n🧾 Hasil Matriks A + B:\n`;
  hasil.forEach(row => {
    langkah += row.join('\t') + '\n';
  });

  document.getElementById("output").innerText = langkah;
}

function kaliMatriks() {
  const { A, B } = ambilMatriks();

  let langkah = "🧮 Langkah-langkah Perkalian Matriks A × B:\n\n";
  let hasil = [[], []];

  for (let i = 0; i < 2; i++) {
    for (let j = 0; j < 2; j++) {
      const value = A[i][0] * B[0][j] + A[i][1] * B[1][j];
      hasil[i][j] = value;
      langkah += `Elemen [${i+1},${j+1}]: (${A[i][0]} × ${B[0][j]}) + (${A[i][1]} × ${B[1][j]}) = ${value}\n`;
    }
  }

  langkah += `\n🧾 Hasil Matriks A × B:\n`;
  hasil.forEach(row => {
    langkah += row.join('\t') + '\n';
  });

  document.getElementById("output").innerText = langkah;
}

function determinan() {
  const { A } = ambilMatriks();
  const det = A[0][0]*A[1][1] - A[0][1]*A[1][0];

  const langkah = `🧮 Langkah-langkah Determinan Matriks A:\n\n` +
                  `Rumus: (a × d) - (b × c)\n` +
                  `= (${A[0][0]} × ${A[1][1]}) - (${A[0][1]} × ${A[1][0]})\n` +
                  `= ${A[0][0]*A[1][1]} - ${A[0][1]*A[1][0]}\n` +
                  `= ${det}\n\n` +
                  `🧾 Determinan Matriks A = ${det}`;

  document.getElementById("output").innerText = langkah;
}
